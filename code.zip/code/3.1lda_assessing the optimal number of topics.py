


if __name__ == '__main__':




    from gensim import corpora
    import matplotlib.pyplot as plt
    import matplotlib
    import numpy as np
    import warnings

    warnings.filterwarnings('ignore')  # To ignore all warnings that arise here to enhance clarity

    from gensim.models.coherencemodel import CoherenceModel
    from gensim.models.ldamodel import LdaModel


    PATH = "target document_clean.txt"

    file_object2 = open(PATH, encoding='utf-8', errors='ignore').read().split('\n')
    data_set = []
    for i in range(len(file_object2)):
        result = []
        seg_list = file_object2[i].split()
        for w in seg_list:
            result.append(w)
        data_set.append(result)
    print(data_set)

    #构建词典，语料向量化表示 Constructing a lexicon, a vectorised representation of the corpus

    dictionary = corpora.Dictionary(data_set)  # 构建词典
    corpus = [dictionary.doc2bow(text) for text in data_set]

    #构建LDA模型 Constructing the LDA model

    ldamodel = LdaModel(corpus, num_topics=10, id2word = dictionary, passes=30,random_state = 1)
    print(ldamodel.print_topics(num_topics=10, num_words=15))


    #计算主题一致性 Calculating Thematic Coherence
    def coherence(num_topics):
        ldamodel = LdaModel(corpus, num_topics=num_topics, id2word = dictionary, passes=200,random_state = 3)
        print(ldamodel.print_topics(num_topics=num_topics, num_words=10))
        ldacm = CoherenceModel(model=ldamodel, texts=data_set, dictionary=dictionary, coherence='c_v')
        print(ldacm.get_coherence())
        return ldacm.get_coherence()

#绘制主题-coherence曲线，以便选择最佳主题数 Plotting topic-coherence curves to select the optimal number of topics

    x = range(1,15)
    #y = [perplexity(i) for i in x]
    y = [coherence(i) for i in x]
    print(x,y)
    plt.plot(x, y)
    plt.xlabel('topic number')
    plt.ylabel('coherence')
    #plt.ylabel('perplexity score')
    plt.rcParams['font.sans-serif']=['SimHei']
    matplotlib.rcParams['axes.unicode_minus']=False
    plt.title('top-coherence change')

    plt.show()