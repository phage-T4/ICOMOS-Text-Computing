


if __name__ == '__main__':


    from gensim.models import LdaModel
    import pandas as pd
    from gensim.corpora import Dictionary
    from gensim import corpora, models
    import csv


    PATH = "target document_clean.txt"

    file_object2 = open(PATH, encoding='utf-8', errors='ignore').read().split('\n')
    data_set = []
    for i in range(len(file_object2)):
        result = []
        seg_list = file_object2[i].split()
        for w in seg_list:
            result.append(w)
        data_set.append(result)

    dictionary = corpora.Dictionary(data_set)
    corpus = [dictionary.doc2bow(text) for text in data_set]

    #remember to change  num_topics=5

    lda = LdaModel(corpus=corpus, id2word=dictionary, num_topics=5, passes=4, random_state=1)
    topic_list = lda.print_topics()
    print(topic_list)

    for i in lda.get_document_topics(corpus)[:]:
        listj = []
        for j in i:
            listj.append(j[1])
        bz = listj.index(max(listj))
        print(i[bz][0])





import pyLDAvis.gensim_models

d = pyLDAvis.gensim_models.prepare(lda, corpus, dictionary,mds='mmds')
pyLDAvis.show(d)
pyLDAvis.save_html(d, 'C:/Users/CC-phage/Desktop/lda_pass6.html')