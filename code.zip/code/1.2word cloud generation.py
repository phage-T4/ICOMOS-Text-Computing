import numpy as np
from PIL import Image
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator

# 读取文本文件 Reading text files
file_name = 'target document_clean.txt'
with open(file_name, "r", encoding='utf-8') as file:
    text = file.read()

# 过滤掉停用词 Filter out stop words
stopwords = set(STOPWORDS)
filtered_words = [word for word in text.split() if word not in stopwords]

# 将单词列表转换为以空格分隔的字符串 Convert a list of words into a space-separated string
text = " ".join(filtered_words)

# 设置词云参数 Setting up word cloud parameters
wc = WordCloud(background_color="white", max_words=200, mask=None,
               contour_width=3, contour_color='steelblue',width=600, height=1000)


wc.generate(text)


wc.to_file("wordcloud.png")
