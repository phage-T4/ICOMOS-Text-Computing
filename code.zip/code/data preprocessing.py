import re
import nltk



from nltk.corpus import stopwords

# 定义停用词 Defining stopwords
stop_words = set(stopwords.words('english'))


# 定义函数进行文本清洗 Define functions for text cleaning
def clean_text(text):

    text = text.lower()

    text = re.sub(r'[^\w\s]', '', text)

    text = re.sub(r'\d+', '', text)

    text = ' '.join(word for word in text.split() if word not in stop_words)
    return text


# 读取文件并进行清洗 Read the file and clean it
with open("target document.txt", 'r', encoding='gbk') as f:
    text = f.read()
    cleaned_text = clean_text(text)

# 将清洗后的文本写入文件  Write cleaned text to a file
with open("target document_clean.txt", 'w', encoding='utf-8') as f:
    f.write(cleaned_text)
