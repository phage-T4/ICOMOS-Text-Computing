import collections

# 读取文本文件并统计单词词频 Read a text file and count word frequencies
file_name ="target document_clean.txt"
with open(file_name, "r", encoding='utf-8') as file:
    text = file.read()
    words = text.split()
    word_counts = collections.Counter(words)


top_words = [word for word, count in word_counts.most_common(30)]

import pandas as pd

# 构建共现矩阵 Constructing the co-occurrence matrix
co_occurrence = pd.DataFrame(columns=top_words, index=top_words).fillna(0)

for i in range(len(words)):
    if words[i] in top_words:
        for j in range(max(0, i - 5), min(len(words), i + 6)):
            if i != j and words[j] in top_words:
                co_occurrence.at[words[i], words[j]] += 1

# 保存共现矩阵为CSV文件 Save the co-occurrence matrix as a CSV file
co_occurrence.to_csv("co_occurrence_matrix.csv")

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 读取共现矩阵 Read the co-occurrence matrix
co_occurrence = pd.read_csv("co_occurrence_matrix.csv", index_col=0)

# 创建热力图 Creating heatmaps
sns.set(rc={'figure.figsize':(16,8)})
sns_plot=sns.heatmap(co_occurrence, cmap="YlGnBu", annot=True, fmt='g')

fig, ax = plt.subplots(figsize=(16, 8))
sns_plot = sns.heatmap(co_occurrence, cmap="YlGnBu", annot=True, fmt='g')
sns_plot.figure.subplots_adjust(left=0.2, bottom=0.2, right=0.8, top=0.8)


plt.title("Co-occurrence Matrix")
sns_plot.figure.savefig("heatmap.png", dpi=300)
plt.show()
