import pandas as pd
from sklearn.cluster import AgglomerativeClustering
from scipy.spatial import distance
from scipy.cluster import hierarchy
import matplotlib.pyplot as plt


# 1. 读取CSV文件 Reading CSV files
co_occurrence_matrix = pd.read_csv('co_occurrence_matrix.csv', index_col=0)



# 2. 执行层次聚类（使用Ward方法，根据簇的数量来停止） Perform hierarchical clustering (using the Ward method, which stops based on the number of clusters)
agg_clustering = AgglomerativeClustering(n_clusters=5, linkage='ward')
agg_clustering.fit(co_occurrence_matrix)

plt.figure(figsize=(30, 18))

# 3. 生成树状图（设置orientation为'left'以垂直方向显示） Generate a tree diagram (set orientation to 'left' to display vertically)
dendrogram = hierarchy.dendrogram(hierarchy.linkage(co_occurrence_matrix, method='ward'), labels=co_occurrence_matrix.columns, orientation='right', leaf_rotation=0, leaf_font_size=12)

# 4. 可视化 visualisation
plt.title('Hierarchical Clustering Dendrogram (Ward)')
plt.xlabel('Distance')
plt.ylabel('Sample Index or Features')
plt.show()