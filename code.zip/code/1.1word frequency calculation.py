import jieba
import pandas as pd

file_name = "target document_clean.txt"
word_freq = {}

with open(file_name, "r") as file:
    for line in file:
        words = jieba.lcut(line)
        for word in words:
            if word not in word_freq:
                word_freq[word] = 1
            else:
                word_freq[word] += 1

# 对词频进行排序，并取前30个条目  Word frequencies are ranked and the top 30 entries are taken
sorted_word_freq = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:31]

# 打印词频前30的单词及其词频  Print the top 30 words and their frequency
for word, freq in sorted_word_freq:
    print(word, freq)





